# Awesome Project Build with TypeORM

Steps to run this project:

1. Run `npm i` command
2. Setup database settings inside `data-source.ts` file
3. Run `npm start` command
"# Web2" 
#   W e b 2  
 "# Laboratorio1" 
"# Laboratorio1" 
