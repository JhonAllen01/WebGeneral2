export interface Usuarios {
  cedula: number;
  nombre: string;
  apellido1: string;
  apellido2: string;
  fecha_ingreso: Date;
  correo: string;
  rol: string;
  contrasena: string;
  estado: boolean;
}
